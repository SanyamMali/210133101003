function alertallby()
{
    alert('External Script');
}
function confirmallby()
{
    confirm('External Script');
}
function promptallby()
{
    prompt('External Script')
}
function bodyBGCP1()
{
    document.body.style.backgroundColor=document.getElementById("C1").value;
}
function divBGCP2()
{
    document.getElementById("D1").style.backgroundColor=document.getElementById("C2").value;
}